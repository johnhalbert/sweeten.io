module.exports = function(app) {
	
	console.log('sweeten.io routes')

}