var mongoose = require('mongoose')

mongoose.conntect('mongodb://localhost/sweeten.io')